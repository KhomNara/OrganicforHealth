package me.mrsaingchakkrey.organicforhealth;

import android.content.Context;
import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;

import java.util.List;

/**
 * Created by MR Saingchakkrey on 01-Jul-18.
 */

public class RecyclerViewAdapterforVegetables extends RecyclerView.Adapter<RecyclerViewAdapterforVegetables.MyviewHolder> {

    Context mChontext;
    List<Vegetables> mData;

    public RecyclerViewAdapterforVegetables(Context mChontext, List<Vegetables> mData) {
        this.mChontext = mChontext;
        this.mData = mData;
    }

    @Override
    public MyviewHolder onCreateViewHolder(ViewGroup parent, int viewType) {

        View v;
        v = LayoutInflater.from(mChontext).inflate(R.layout.vegetables_items, parent, false);
        MyviewHolder vHolder = new MyviewHolder(v);

        return vHolder;
    }

    @Override
    public void onBindViewHolder(MyviewHolder holder, int position) {

        holder.tv_name.setText(mData.get(position).getName());
        holder.tv_price.setText(mData.get(position).getPrice());
        holder.img.setImageResource(mData.get(position).getPhoto());
        holder.desc.setText(mData.get(position).getDesc());
    }

    @Override
    public int getItemCount() {
        return mData.size();
    }

    public static class MyviewHolder extends RecyclerView.ViewHolder {

        private TextView tv_name;
        private TextView tv_price;
        private ImageView img;
        private TextView desc;

        public MyviewHolder(View itemView) {
            super(itemView);

            tv_name = (TextView) itemView.findViewById(R.id.fruitname);
            tv_price = (TextView) itemView.findViewById(R.id.price);
            img = (ImageView) itemView.findViewById(R.id.img_fruits);
            desc = (TextView) itemView.findViewById(R.id.desc);
        }
    }
}
