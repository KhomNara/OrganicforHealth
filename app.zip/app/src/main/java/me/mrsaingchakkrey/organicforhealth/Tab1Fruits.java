package me.mrsaingchakkrey.organicforhealth;

/**
 * Created by MR Saingchakkrey on 29-Jun-18.
 */

import android.support.annotation.Nullable;
import android.support.v4.app.Fragment;
import android.os.Bundle;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import java.util.ArrayList;
import java.util.List;

public class Tab1Fruits  extends Fragment {

    View v;
    private RecyclerView recyclerView;
    private List<Fruits> lstFruits;

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        View rootView = inflater.inflate(R.layout.tab1_fruits, container, false);
        recyclerView = (RecyclerView) rootView.findViewById(R.id.fruits_recyclerview);
        RecyclerViewAdapterforFruits recyclerViewAdapter = new RecyclerViewAdapterforFruits(getContext(), lstFruits);
        recyclerView.setLayoutManager(new LinearLayoutManager(getActivity()));
        recyclerView.setAdapter(recyclerViewAdapter);
        return rootView;
    }

    @Override
    public void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        lstFruits = new ArrayList<>();
        lstFruits.add(new Fruits("Organic Black Grapes", "$4.99/1Kg", R.drawable.fblack_grapes, "Bite one of these and taste liquid autumn. Their full, fleshy flavor makes them a perfect dessert grape."));
        lstFruits.add(new Fruits("Honeycrisp Apples", "$9.99/1Kg", R.drawable.fhoneycrisp_apple, "True to its name, the honeycrisp is sweet and crunchy with a warm, yellow interior and an attractive yellow-red streaked skin"));
        lstFruits.add(new Fruits("Navel oranges", "$8.99/1Kg", R.drawable.fnavel_oranges, "Extra-big, beautiful, seedless, very low in acid and filled with mild, sweet flesh. These beauties are supremely simple to peel and section."));
        lstFruits.add(new Fruits("Red Cherries", "$8.99/1Kg", R.drawable.fred_cherries, "We dare you to eat just one of these irresistible sweet-tart fruits. Their shine and juiciness work hand in hand to keep you dipping into the fruit bowl until they're all gone."));
        lstFruits.add(new Fruits("Rainier Honeycrisp Apples", "$9.99/1Kg", R.drawable.frainier_honeycrisp_apples, "True to its name, the honeycrisp is sweet and crunchy with a warm, yellow interior and an attractive yellow-red streaked skin. We love this healthy treat packed in a lunch, sliced for after-school snacks or as a take-along for your anytime snacking."));
        lstFruits.add(new Fruits("White Peaches", "$2.99/1Kg", R.drawable.fwhite_peaches, "The white peach is a soft, smooth, honey-flavored version of its orange cousin. The flavor is mild, delicate, and deliciously sweet. The aroma is like a flower store. Cooking with these special peaches would be doing them a disservice."));
        lstFruits.add(new Fruits("Avocados", "$4.99/1Kg", R.drawable.fhass_avocados, "These gorgeous Hass avocados are shipped to you ready to eat! Don't delay in enjoying the buttery texture and rich, slightly sweet flavor. We love to plump up burritos, sandwiches and salads with these \"butter pears,\" but they also make a satisfying addition to health smoothies to start your day off right."));
        lstFruits.add(new Fruits("Strawberries", "$4.49/1Kg", R.drawable.fstrawberries, "Driscoll's Strawberries are consistently the best, sweetest, juiciest strawberries available. This size is the best selling, as it is both convenient for completing a cherished family recipes and for preparing a quick snack straight from the fridge."));
        lstFruits.add(new Fruits("Bosc Pear", "$1.29/1Kg", R.drawable.fbosc_pear, "Melt-in-your-mouth texture with hints of vanilla and apple-blossom honey. Its slightly thick skin hides a creamy-crisp fruit with more tartness than other pears. The Bosc is known as the best cooking pear, and it's also at the top of our list for eating raw."));
        lstFruits.add(new Fruits("Gala Apples", "$5.99/1Kg", R.drawable.fgala_apples, "The light golden streaks of color on the outside of the Gala hint at the honey-floral taste on the inside. We think there's a touch of banana in there, too. Sweet with a medium-crisp bite, the Gala looks like a beautiful old-time fruit-stand apple. Its delicate taste gets a boost from the slightly tart skin."));


    }
}
