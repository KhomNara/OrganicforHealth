package me.mrsaingchakkrey.organicforhealth;

/**
 * Created by MR Saingchakkrey on 01-Jul-18.
 */

public class Vegetables {

    private String Name;
    private String Price;
    private int Photo;
    private String Desc;

    public Vegetables() {
    }

    public Vegetables(String name, String price, int photo, String desc) {
        Name = name;
        Price = price;
        Photo = photo;
        Desc = desc;
    }

    public String getName() {
        return Name;
    }

    public String getPrice() {
        return Price;
    }

    public int getPhoto() {
        return Photo;
    }

    public String getDesc() {
        return Desc;
    }


}
