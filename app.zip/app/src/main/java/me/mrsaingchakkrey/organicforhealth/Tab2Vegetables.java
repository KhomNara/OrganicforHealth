package me.mrsaingchakkrey.organicforhealth;

import android.os.Bundle;
import android.support.annotation.Nullable;
import android.support.v4.app.Fragment;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import java.util.ArrayList;
import java.util.List;

/**
 * Created by MR Saingchakkrey on 29-Jun-18.
 */

public class Tab2Vegetables extends Fragment {

    View v;
    private RecyclerView recyclerView;
    private List<Vegetables> lstVegetables;



    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        View rootView = inflater.inflate(R.layout.tab2_vegetables, container, false);
        recyclerView = (RecyclerView) rootView.findViewById(R.id.vegetables_recyclerview);
        RecyclerViewAdapterforVegetables recyclerViewAdapter = new RecyclerViewAdapterforVegetables(getContext(), lstVegetables);
        recyclerView.setLayoutManager(new LinearLayoutManager(getActivity()));
        recyclerView.setAdapter(recyclerViewAdapter);
        return rootView;
    }

    @Override
    public void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        lstVegetables = new ArrayList<>();
        lstVegetables.add(new Vegetables("Broccoli", "$3.49/1Kg", R.drawable.vbroccoli, "With its cabbage-like flavor and satisfying crunch, we think of broccoli as one of the ultimate vegetables. It's nutritious, low in calories, available year-round and hearty. Steam it, stir-fry it, sauté it, bake it in casseroles, purée it in soups or dunk it raw in dressing or hummus."));
        lstVegetables.add(new Vegetables("Brussels Sprouts", "$3.49/1Kg", R.drawable.vbrussels, "Delicate, earthy flavor with hints of nuttiness. These hearty little green nuggets pack loads of healthful fiber and antioxidants, with a tiny calorie count. Not everyone agrees that Brussels sprouts originated in Brussels. We do know, though, that the fields of Belgium are full of them."));
        lstVegetables.add(new Vegetables("Wild Foraged", "$14.99/1Kg", R.drawable.vwild, "Morels taste of the woods where they grow wild: smoky, earthy, and nutty. They are harvested in the spring and early summer. The honeycomb texture of the morel captures and enhances flavors."));
        lstVegetables.add(new Vegetables("Carrots", "$5.99/1Kg", R.drawable.vcarrots, "Colorful, crunchy and very sweet! These multi-colored carrots are lovely to look at and even lovelier to snack on. We suggest enjoying them raw, either as part of a festive crudité platter or shredded in a salad."));
        lstVegetables.add(new Vegetables("Celery", "$5.99/1Kg", R.drawable.vcelery, "For centuries, celery was only eaten cooked, but now the crunch of its raw form is considered one of its best qualities. Celery is a little salty, just a tad bitter, and it has a hint of mineral flavor. It makes the crispiest dip accompaniment or spread with creamy peanut butter."));
        lstVegetables.add(new Vegetables("Corn", "$0.79/1Kg", R.drawable.vcorn, "Sun-gold, sweet, crunchy perfection, with crisp, milky kernels that burst when bitten. Corn is a native American crop that's really a grass. It has grown on our continent for tens of thousands of years. We love this classic simply boiled and slathered in butter."));
        lstVegetables.add(new Vegetables("Cucumbers", "$3.99/1Kg", R.drawable.vcucumbers, "A truly super cuke. Hothouse cucumbers are green, fresh-tasting, and almost minty. At least a foot long and seedless, they are sometimes called \"burpless\" because their thin skins are easy to digest. They make the most refined teatime sandwiches."));
        lstVegetables.add(new Vegetables("Pre-cut", "$4.99/1Kg", R.drawable.vprecut, "Simply younger, smaller versions of the big, meaty grill-lovin' mushroom you already know and love, these little baby brothers love all the same cooking treatments as the big 'bellas. These come pre-sliced, so they're ready to sauté or toss into a braise."));
        lstVegetables.add(new Vegetables("Snack Packs", "$5.99/1Kg", R.drawable.vsnackpacks, "For centuries, celery was only eaten cooked, but now the crunch of its raw form is considered one of its best qualities. Celery is a little salty, just a tad bitter, and it has a hint of mineral flavor. It makes the crispiest dip accompaniment or spread with creamy peanut butter."));
        lstVegetables.add(new Vegetables("Eggplant", "$1.99/1Kg", R.drawable.veggplant, "Lush and creamy, with a mild, earthy flavor, eggplant has the most velvety texture in the vegetable family. It's high in healthy fiber. We love it sliced, brushed with olive oil and salt, and grilled or roasted."));


    }
}
